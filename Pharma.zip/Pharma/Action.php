<?php

$con = mysqli_connect("localhost", "root", "", "add");
//echo var_dump($_POST);


$productname = mysqli_real_escape_string($con, $_POST['productname']);
$describe = mysqli_real_escape_string($con,  $_POST['describe']);
$composition = mysqli_real_escape_string($con,  $_POST['composition']);
$manufacure = mysqli_real_escape_string($con,  $_POST['manufacure']);



	$q = mysqli_query($con,  "INSERT INTO `data` VALUES('".$productname."','".$describe."', '".$composition."', '".$manufacure."') ");
	@header("location: Addproducts.html");

?>
