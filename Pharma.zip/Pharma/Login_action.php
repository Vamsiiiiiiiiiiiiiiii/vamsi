
<?php
	session_start();
	$con = mysqli_connect("localhost", "root", "", "patient");

	
	$username= $_POST['username'];
	$password = $_POST['password'];
	
	$result = mysqli_query($con, "SELECT * FROM data WHERE username = '".$username."' AND password = '".$password."'");
	
	if (mysqli_num_rows($result) != 0) {
		$_SESSION['username'] = $username;
		header("Location: Paitent_dashboard.html");
	} 
?>
