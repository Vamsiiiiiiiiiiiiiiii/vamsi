<?php
	session_start();
	
	include ('dbconn.php');
	
	$comment = nl2br(addslashes($_POST['comment']));
	$cid = $_GET['cid'];
	$scid = $_GET['scid'];
	$tid = $_GET['tid'];
	
	$insert = mysqli_query($con,"INSERT INTO replies(`cat_id`, `subcat_id`, `topic_id`, `author`, `comment`, `date_posted`) VALUES ('".$cid."','".$scid."','".$tid."','".$_SESSION['rollno']."','".$comment."',NOW())");
		
		echo $insert;						  
	if ($insert) {
		//header("Location: readtopic.php?cid=$cid&scid=$scid&tid=$tid");
	}
	else echo "error";
?>