<?php

$con = mysqli_connect("localhost", "root", "", "medicine");
//echo var_dump($_POST);


$username = mysqli_real_escape_string($con, $_POST['username']);
$hospital = mysqli_real_escape_string($con,  $_POST['hospital']);
$gender = mysqli_real_escape_string($con,  $_POST['gender']);
$specialization = mysqli_real_escape_string($con,  $_POST['specialization']);
$password = mysqli_real_escape_string($con,  $_POST['password']);




	$q = mysqli_query($con,  "INSERT INTO `data` VALUES('".$username."','".$hospital."', '".$gender."', '".$specialization."','".$password."') ");
	@header("location: Doctor.html");

?>
