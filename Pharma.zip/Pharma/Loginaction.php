
<?php
	session_start();
	$con = mysqli_connect("localhost", "root", "", "Data");

	
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$result = mysqli_query($con, "SELECT email, password FROM register WHERE email = '".$email."' AND password = '".$password."'");
	
	if (mysqli_num_rows($result) != 0) {
		$_SESSION['email'] = $email;
		
		header("Location: Aboutus.html");
	} 
	else{
		header("Location: Login.html");

	}
?>
