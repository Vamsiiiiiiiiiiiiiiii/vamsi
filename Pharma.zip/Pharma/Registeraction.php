<?php
if(isset($_POST["submit"])){
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "patient";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO data (username,password,mobileno,gender,amoureux)
VALUES ('".$_POST["username"]."','".$_POST["password"]."','".$_POST["mobileno"]."','".$_POST["gender"]."','".$_POST["date"]."')";

if ($conn->query($sql) === TRUE) {
echo "<script type= 'text/javascript'>alert('New record created successfully');</script>";
} else {
echo "<script type= 'text/javascript'>alert('Error: " . $sql . "<br>" . $conn->error."');</script>";
}

@header("location: Login.html");

$conn->close();
}
?>
